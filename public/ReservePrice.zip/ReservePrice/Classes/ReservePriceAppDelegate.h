//
//  ReservePriceAppDelegate.h
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@class SceneOneController;
@class SceneTwoController;
@class StarsViewController;


@interface ReservePriceAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	SceneOneController *mySceneOne;
	SceneTwoController *mySceneTwo;
	StarsViewController *mySceneThree;
	AVAudioPlayer *mySoundtrack;
}


@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (retain) SceneOneController *mySceneOne;
@property (retain) SceneTwoController *mySceneTwo;
@property (retain) StarsViewController *mySceneThree;
@property (retain) AVAudioPlayer *mySoundtrack;


@end

