//
//  StarsViewController.h
//  Demo
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface StarsViewController : UIViewController {
	NSMutableArray *stars;
	int loop;
	int angle;
	
	CGFloat *precos;
	CGFloat *presin;
	CGFloat *speeds;
	int *distances;
	BOOL isFinished;
	NSTimer *myTimer;
}

@property (retain) NSTimer *myTimer;
@property BOOL isFinished;
@property (nonatomic, retain) NSMutableArray *stars;

-(CGFloat)circlePoCGFloatX:(CGFloat)distance andRadians:(CGFloat) radians;
-(CGFloat)circlePoCGFloatY:(CGFloat)distance andRadians:(CGFloat) radians;
-(CGFloat)circlePoCGFloatX:(CGFloat)distance andLoop:(int)i;
-(CGFloat)circlePoCGFloatY:(CGFloat)distance andLoop:(int)i;

@end
