/*	TPPlasmaView.h
	(c) 2007 Daniel Stoedle, daniel@scsc.no
*/

#ifndef TPPLASMAVIEW_H
	#define TPPLASMAVIEW_H

//	Includes
	#import <CoreGraphics/CoreGraphics.h>
	#import <UIKit/UIKit.h>
	//#import <UIKit/UIView.h>
	//#import <UIKit/UITextView.h>
	//#import <UIKit/UITouchDiagnosticsLayer.h>
	//#import <UIKit/UINavBarButton.h>
	//#import <GraphicsServices/GraphicsServices.h>
	#import <stdlib.h>
	#import <signal.h>
	#include <time.h>

//	Constants
enum {
	kTranspose_radius			= 4,
	kNum_rand_table_elems		= 65536,
	kNum_seed_fragments			= 32*3,
};

#define	kFragment_lifetime				15
#define	kFragment_max_velocity			9.0
#define kFragment_deceleration_factor	.98

typedef struct _fragment_t fragment_t;
struct _fragment_t {
	time_t		life_expiry_time;
	float		x, y, vx, vy;
	int			sent;
	fragment_t	*next;
};

#define	mod_rand(m)	((rand() & 0x7FFFFFFF) % m)

//	Classes

@interface TPPlasmaView : UIView {
	int		_orientationState,
			_orientationDeg;
	CGContextRef	bm_ctx;
	CGImageRef		img;
	void			*pixels;
	uint32_t		width,
					height,
					rowBytes;
	
	uint32_t		*color_table;
	int				transp_rand_tbl[kNum_rand_table_elems];
	uint16_t		transp_rand_idx;
	uint8_t			*plasma_area;
	fragment_t		*fragments;
	int				plasma_width,
					plasma_height;
	CGPoint			gravity,
					inertia;
}
- (void)setOrientationState:(UIDeviceOrientation)state;
- (void)seedPixelAtX:(int)x y:(int)y;
- (void)updateFragments;
- (void)createFragments:(CGPoint)where;
- (void)fadePixels;
- (void)buildFireColorTable;
- (void)modifyInertia:(float)x y:(float)y;
@end

#endif
