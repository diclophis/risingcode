/*	TouchPlasma.h
	(c) 2007 Daniel Stoedle, daniel@scsc.no
*/

#ifndef TOUCHPLASMA_H
	#define TOUCHPLASMA_H

//	Includes
	#import <CoreGraphics/CoreGraphics.h>
	#import <UIKit/UIKit.h>
	#import <UIKit/UITextView.h>
	//#import <UIKit/UITouchDiagnosticsLayer.h>
	//#import <UIKit/UINavBarButton.h>
	//#import <GraphicsServices/GraphicsServices.h>
	#import <stdlib.h>
	#import <signal.h>

//	Classes

@class TPPlasmaView;

@interface TouchPlasma : UIApplication {
	UIWindow			*_window;
	UIView				*_mainView;
	//UITransitionView	*_transView;
	TPPlasmaView		*_plasmaView;
}
- (void)initHIDEvents:(int)hz;
@end

#endif
