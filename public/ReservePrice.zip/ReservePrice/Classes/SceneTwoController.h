//
//  SceneTwoController.h
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SceneTwoController : UIViewController {
	NSTimer *myTimer;
	CGFloat time;
	NSMutableArray *myLetters;
	UIImageView *myBackground;
}


@property (retain) UIImageView *myBackground;
@property (retain) NSMutableArray *myLetters;
@property (retain) NSTimer *myTimer;


@end
