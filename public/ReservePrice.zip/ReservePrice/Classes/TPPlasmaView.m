/*	TPPlasmaView.m
	(c) 2007 Daniel Stoedle, daniel@scsc.no
*/

#import "TPPlasmaView.h"
#include "data_provider.h"


@implementation TPPlasmaView
- (id)initWithFrame:(CGRect)frame {
	if ((self = [super initWithFrame:frame]) != 0) {
		CGColorSpaceRef			color_space;
		CGDataProviderRef		provider;
		int						depth = 32, i;
		
		[self setOpaque:YES];
		[NSTimer scheduledTimerWithTimeInterval:1.0/30.0 target:self selector:@selector(updateTimer:) userInfo:0 repeats:YES];
		width			= frame.size.width;
		height			= frame.size.height;
		rowBytes		= width*(depth/4);
		pixels			= malloc(height*rowBytes);
		color_space		= CGColorSpaceCreateDeviceRGB();
		provider		= create_data_provider(pixels, height*rowBytes, 1, 1);
		img				= CGImageCreate(width, height, 8, depth, rowBytes, color_space, kCGImageAlphaPremultipliedFirst, provider, 0, 0, kCGRenderingIntentDefault);
		CGDataProviderRelease(provider);
		bm_ctx			= CGBitmapContextCreate(pixels, width, height, 8, rowBytes, color_space, kCGImageAlphaPremultipliedFirst);
		CGColorSpaceRelease(color_space);
		
		plasma_width	= width+4*kTranspose_radius;
		plasma_height	= height+4*kTranspose_radius;
		[self buildFireColorTable];
		plasma_area		= malloc(plasma_width*plasma_height);
		color_table[1]	= 0x000000FF;
		color_table[0]	= 0;
		for (i=0;i<kNum_rand_table_elems;i++) {
			transp_rand_tbl[i]			= mod_rand(kTranspose_radius);
			if (mod_rand(2))
				transp_rand_tbl[i]  = -transp_rand_tbl[i];
		}
		gravity.x	= 0.;
		gravity.y	= -0.3;
	}
	return self;
}


- (void)dealloc {
	if (img)
		CGImageRelease(img);
	if (bm_ctx)
		CGContextRelease(bm_ctx);
	if (color_table)
		free(color_table);
	if (plasma_area)
		free(plasma_area);
	//	pixels is free'd by data provider
	//	TODO: Free fragments
	
	[super dealloc];
}


- (void)updateTimer:(NSTimer*)timer {
	[self updateFragments];
	[self fadePixels];
	[self setNeedsDisplay];
}


- (void)seedPixelAtX:(int)x y:(int)y {
	plasma_area[x+2*kTranspose_radius+((y+2*kTranspose_radius)*plasma_width)]	= 255;
}


- (void)drawRect:(CGRect)rect {
	
	CGContextRef	ctx = UIGraphicsGetCurrentContext(); //CGC //CGLayerGetContext(self.layer);
	CGContextDrawImage(ctx, rect, img);
}

/*
- (UIHardwareOrientation)getOrientationState {
	return _orientationState;
}
 
*/

- (void)setOrientationState:(UIDeviceOrientation)wState {
	switch (wState) {
		case UIDeviceOrientationLandscapeRight:
			gravity.x	= 0.3;
			gravity.y	= 0.;
			break;
		case UIDeviceOrientationLandscapeLeft:
			gravity.x	= -0.3;
			gravity.y	= 0.;
			break;
		case UIDeviceOrientationPortrait:
			gravity.x	= 0.;
			gravity.y	= -0.3;
			break;
		case UIDeviceOrientationPortraitUpsideDown:
			gravity.x	= 0.;
			gravity.y	= 0.3;
			break;
		case UIDeviceOrientationFaceUp:
			gravity.x	= 0.;
			gravity.y	= 0.;
			break;
		default:
			break;
	}
}


- (void)updateFragments {
	fragment_t		*cur, *prev = 0, *next;
	time_t			now = time(0);
	int				remove_fragment;
	
	now	= time(0);
	for (cur=fragments;cur;cur=next) {
		next			= cur->next;
		remove_fragment	= 0;
		
		cur->x	+= cur->vx;
		cur->y	+= cur->vy;
		cur->vx	*= kFragment_deceleration_factor;
		cur->vy	*= kFragment_deceleration_factor;
		cur->vy	+= gravity.y+inertia.x;
		cur->vx	+= gravity.x+inertia.y;
		if (cur->x < -kTranspose_radius || cur->x >= width+kTranspose_radius || cur->y < -kTranspose_radius || cur->y >= height+kTranspose_radius) {
			remove_fragment	= 1;
		}
		else if (now > cur->life_expiry_time)
			remove_fragment	= 1;
		
		if (remove_fragment) {
			if (prev)
				prev->next	= next;
			else
				fragments	= next;
			free(cur);
		}
		else {
			[self seedPixelAtX:cur->x y:cur->y];
			prev	= cur;
		}
	}
	inertia.x	*= kFragment_deceleration_factor;
	inertia.y	*= kFragment_deceleration_factor;
}



- (void)createFragments:(CGPoint)where {
	fragment_t	*frag;
	int			i, x = where.x, y = where.y;
	time_t		now = time(0);
	
	for (i=0;i<kNum_seed_fragments;i++) {
		frag	= calloc(1, sizeof(fragment_t));
		frag->next	= fragments;
		fragments	= frag;
		
		frag->x		= x;
		frag->y		= y;
		frag->vx	= mod_rand(((int)(kFragment_max_velocity)));
		frag->vy	= mod_rand(((int)(kFragment_max_velocity)));
		if (mod_rand(2))
			frag->vx	= -frag->vx;
		if (mod_rand(2))
			frag->vy	= -frag->vy;
		frag->life_expiry_time	= now+kFragment_lifetime;
	}
}


- (void)fadePixels {
	int				y, x, xx, yy, w, h;
	uint8_t			*pixel, *line, *tmp, value;
	uint32_t		*px_line, avg;
	
	w	= width;
	h	= height;
	for (y=kTranspose_radius;y<plasma_height-kTranspose_radius;y++) {
		line	= plasma_area+(y*plasma_width);
		for (x=kTranspose_radius;x<plasma_width-kTranspose_radius;x++) {
			pixel			= (line + x);
			xx				= x+transp_rand_tbl[transp_rand_idx++];
			yy				= y+transp_rand_tbl[transp_rand_idx++];
			
			tmp				= plasma_area+(yy*plasma_width)+xx;
			avg				= *tmp + *(pixel+1) + *(pixel-1) + *(pixel+plasma_width) + *(pixel-plasma_width);
			value			= (uint8_t)((avg+*pixel)/6);
			*pixel			= value;
		}
	}
	for (y=0;y<h;y++) {
		line	= plasma_area+((y+2*kTranspose_radius)*plasma_width)+2*kTranspose_radius;
		px_line	= (uint32_t*)(pixels+(y*rowBytes));
		pixel	= line;
		for (x=0;x<w;x++) {
			*(px_line+x)	= color_table[*pixel];
			pixel++;
		}
	}
	for (y=0;y<kTranspose_radius;y++) {
		line	= plasma_area+y*plasma_width;
		pixel	= line;
		for (x=0;x<plasma_width;x++)
			pixel[x]	= 0;
	}
	for (y=h+3*kTranspose_radius;y<plasma_height;y++) {
		line	= plasma_area+y*plasma_width;
		pixel	= line;
		for (x=0;x<plasma_width;x++)
			pixel[x]	= 0;
	}
	for (y=0;y<plasma_height;y++) {
		line	= plasma_area+y*plasma_width;
		pixel	= line;
		for (x=0;x<kTranspose_radius;x++)
			pixel[x]	= 0;
		for (x=w+3*kTranspose_radius;x<plasma_width;x++)
			pixel[x]	= 0;
	}
}


- (void)buildFireColorTable {
	uint32_t			*table;
	int					i, r=0, g=0, b=0, rs=0, gs=0, bs=0, si,
						ramp[4][3]	= { { 0, 0, 0},
										{ 256, 0, 0},
										{ 256, 256, 0 },
										{ 256, 256, 256 }
									  },
						limits[]	= { 0, 64, 128, 192 };
	
	table		= calloc(256, sizeof(uint32_t));
	si			= 0;
	for (i=0;i<256;i++) {
		if (i==limits[si]) {
			r   = ramp[si][0];
			g   = ramp[si][1];
			b   = ramp[si][2];
			si++;
			rs  = ramp[si][0];
			gs  = ramp[si][1];
			bs  = ramp[si][2];
			rs  = (rs - r) / (limits[si]-limits[si-1]);
			gs  = (gs - g) / (limits[si]-limits[si-1]);
			bs  = (bs - b) / (limits[si]-limits[si-1]);
		}
		if (r > 255)
			r		= 255;
		if (g > 255)
			g		= 255;
		if (b > 255)
			b		= 255;
		table[i]	= b << 24 | g << 16 | r << 8 | 0xFF;
		r			+= rs;
		g			+= gs;
		b			+= bs;
	}
	color_table		= table;
}

/*
- (void)mouseDown:(GSEvent*)event {
	CGRect	where;
	CGPoint	flip;
	
	where = GSEventGetLocationInWindow(event);
	flip	= where.origin;
	flip.y	= height-flip.y;
	[self createFragments:flip];
}

- (void)mouseDragged:(GSEvent*)event {
	[self mouseDown:event];
}
 */

- (BOOL)canBecomeFirstResponder { return YES; }


- (void)modifyInertia:(float)x y:(float)y {
	//	This stuff isn't working as well as I want it to, mostly because I
	//	haven't had time to study the output from the accelerometer.
	
	//inertia.x	= x;
	//inertia.y	= y;
}
@end
