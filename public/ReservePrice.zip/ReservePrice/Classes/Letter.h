//
//  Letter.h
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Letter : UILabel {
	NSString *myCharacter;
}


@property (retain) NSString *myCharacter;


-(id)initWithCharacter:(NSString *)theCharacter;


@end
