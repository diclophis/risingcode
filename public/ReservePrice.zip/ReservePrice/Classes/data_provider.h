/*  data_provider.h
	Copyright (c) 2004-2007 Yellow Lemon Software, all rights reserved.
*/

#ifndef DATA_PROVIDER_H
	#define DATA_PROVIDER_H
	
	#import <CoreGraphics/CoreGraphics.h>

//  Structs
typedef struct {
	char		*data;
	uint32_t	length,
				index,
				free_data_on_release,
				debug,
				direct,
				can_free;
} data_provider_info_t;

//  Exported globals
extern CGDataProviderCallbacks	dp_provider_callbacks;

//  Prototypes
CGDataProviderRef	create_data_provider(void *data, uint32_t length, int free_on_release, int direct);
const void*	get_byte_pointer(void *info);
void		release_byte_pointer(void *info, const void *pointer);
size_t		get_bytes(void *info, void *buf, size_t count);
void		skip_bytes(void *info, size_t count);
void		provider_rewind(void *info);
void		release_info(void *info);
#endif
