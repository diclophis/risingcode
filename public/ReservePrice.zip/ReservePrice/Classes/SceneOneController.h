//
//  SceneOneController.h
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@interface SceneOneController : UIViewController <AVAudioPlayerDelegate> {
	UIButton *myButton;
	UIImageView *myBackground;
	UIImageView *myBroken;
	NSInteger timesTouched;
	NSTimer *myTimer;
	CGFloat x;
	AVAudioPlayer *mySound;
	BOOL isFinished;
	BOOL almostFinished;
}


@property BOOL almostFinished;
@property BOOL isFinished;
@property (retain) AVAudioPlayer *mySound;
@property (retain) NSTimer *myTimer;
@property (retain) UIButton *myButton;
@property (retain) UIImageView *myBackground;
@property (retain) UIImageView *myBroken;

-(IBAction)didTouchButton:(id)sender;


@end
