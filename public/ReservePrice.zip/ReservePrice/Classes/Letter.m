//
//  Letter.m
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Letter.h"


@implementation Letter


@synthesize myCharacter;


-(id)initWithCharacter:(NSString *)theCharacter {
	if (self = [super initWithFrame:CGRectMake(0.0f, 0.0f, 40.0f, 50.0f)]) {
		[self setMyCharacter:theCharacter];
		[self setBackgroundColor:[UIColor clearColor]];
		[self setFont:[UIFont boldSystemFontOfSize:40.0f]];
		[self setText:myCharacter];
	}
	return self;
}


@end
