/*  data_provider.c
	Copyright (c) 2004-2007 Yellow Lemon Software, all rights reserved.
*/

#include "data_provider.h"

CGDataProviderCallbacks				dp_provider_callbacks	= { get_bytes, skip_bytes, provider_rewind, release_info };
CGDataProviderDirectAccessCallbacks	dp_direct_callbacks		= { get_byte_pointer, release_byte_pointer, 0, release_info };

CGDataProviderRef	create_data_provider(void *data, uint32_t length, int free_on_release, int direct) {
	data_provider_info_t	*dp;
	CGDataProviderRef		provider;
	
	dp							= calloc(1, sizeof(data_provider_info_t));
	dp->free_data_on_release	= free_on_release;
	dp->length					= length;
	dp->data					= data;
	dp->direct					= direct;
	dp->can_free				= 1;
	if (direct)
		provider				= CGDataProviderCreateDirectAccess(dp, dp->length, &dp_direct_callbacks);
	else
		provider				= CGDataProviderCreate(dp, &dp_provider_callbacks);
	return provider;
}


const void*		get_byte_pointer(void *info) {
	data_provider_info_t	*dp = (data_provider_info_t*)info;
	dp->can_free	= 0;
	return ((data_provider_info_t*)info)->data;
}


void			release_byte_pointer(void *info, const void *pointer) {
	data_provider_info_t	*dp = (data_provider_info_t*)info;
	if (pointer == dp->data)
		dp->can_free	= 1;
}

size_t		get_bytes(void *info, void *buf, size_t count) {
	data_provider_info_t	*dp = (data_provider_info_t*)info;
	
	//printf("DP: %8p  Count [before prune]: %8d  ", dp, count);
	if (count > (dp->length - dp->index))
		count   = dp->length - dp->index;
	
	//printf("Count now: %8d  Index: %8d  Length: %8d [data @ %8p, buf @ %8p]\n", count, dp->index, dp->length, dp->data, buf);
	memcpy(buf, dp->data+dp->index, count);
	dp->index   += count;
	return count;
}


void		skip_bytes(void *info, size_t count) {
	data_provider_info_t	*dp = (data_provider_info_t*)info;
	dp->index	+= count;
}


void		provider_rewind(void *info) {
	data_provider_info_t	*dp = (data_provider_info_t*)info;
	dp->index	= 0;
}

void		release_info(void *info) {
	data_provider_info_t	*dp = (data_provider_info_t*)info;

	if (dp->free_data_on_release) {
		free(dp->data);
		if (dp->direct && !dp->can_free)
			printf("Warning: Freeing unreleased byte pointer!\n");
		if (dp->debug)
			printf("free data.. bytes: %d\n", dp->length);
	}
	else if (dp->debug)
		printf("dont free.. bytes: %d\n", dp->length);
	free(dp);
}
