/*	TouchPlasma.m
	(c) 2007 Daniel Stoedle, daniel@scsc.no
*/

#import "TouchPlasma.h"
#import "TPPlasmaView.h"
//#include <IOKit/IOKitLib.h>

void handle_interrupt_signal(int sig) {
	printf("received signal %d, exiting", sig);
	//[UIApp terminate];
}


@implementation TouchPlasma

- (void)applicationDidFinishLaunching:(NSNotification *)unused {
	CGRect	screen_rect = CGRectMake(0.0f, 0.0f, 320.0f, 480.0f),
			frame		= CGRectMake(0.0f, 0.0f, screen_rect.size.width, screen_rect.size.height),
			plasmaFrame	= frame;
	
	signal(SIGINT, handle_interrupt_signal);
	
	_mainView	= [[UIView alloc] initWithFrame:frame];
	//_transView	= [[UITransitionView alloc] initWithFrame:frame];
	//[_mainView addSubview:_transView];
	
	//plasmaFrame.size.height += [self statusBarRect].size.height;
	_plasmaView = [[TPPlasmaView alloc] initWithFrame:plasmaFrame];
	
	//[_transView transition:0 toView:_plasmaView];
	/*
	_window = [[UIWindow alloc] initWithContentRect:screen_rect];
	[_window setContentView:_mainView];
	[_window orderFront:0];
	[_window makeKey:0];
	[_window _setHidden:NO];
	
	[self reportAppLaunchFinished];
	[self initHIDEvents:30];
	//	printf's don't appear anywhere, so we'll do our own logging to two files.
	freopen("/var/log/touchplasma.out", "w", stdout);
	freopen("/var/log/touchplasma.err", "w", stderr);
	 */
}


- (void)dealloc {
	[_window release];
	[super dealloc];
}


- (void)initHIDEvents:(int)hz {
	/*	Adapted from code at http://blog.medallia.com/2007/08/iphone_accelerometer_source_co.html */
	mach_port_t			master	= 0;
	int					res, i,
						rv		= 1000000/hz,
						page	= 0xff00,
						usage	= 3;
	CFNumberRef			nums[2]		= {0,0}, cn = 0;
	CFStringRef			keys[2]		= {0,0}, cs = 0;
	CFDictionaryRef		dict		= 0;
	IOHIDEventSystemRef sys			= 0;
	CFArrayRef			services	= 0;
	io_registry_entry_t service		= 0;
	keys[0] = CFStringCreateWithCString(0, "PrimaryUsagePage", 0);
	keys[1] = CFStringCreateWithCString(0, "PrimaryUsage", 0);
	nums[0] = CFNumberCreate(0, kCFNumberSInt32Type, &page);
	nums[1] = CFNumberCreate(0, kCFNumberSInt32Type, &usage);
	dict	= CFDictionaryCreate(0, (const void**)keys, (const void**)nums, 2, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
	cs		= CFStringCreateWithCString(0, "ReportInterval", 0);
	cn		= CFNumberCreate(0, kCFNumberSInt32Type, &rv);
	res	= IOMasterPort(MACH_PORT_NULL, &master);
	if (res)
		goto cleanup;
	
	sys			= IOHIDEventSystemCreate(0);
	services	= (CFArrayRef)IOHIDEventSystemCopyMatchingServices(sys, dict, 0, 0, 0);
	if (CFArrayGetCount(services) > 0) {
		service = (io_registry_entry_t)CFArrayGetValueAtIndex(services, 0);
		if (!service)
			goto cleanup;
	}
	else
		goto cleanup;
	
	res	= IOHIDServiceSetProperty(service, cs, cn);
	if (res != 1)
		goto cleanup;
	
	res = IOHIDEventSystemOpen(sys, handleHIDEvent, 0, self);
cleanup:
	for (i=0;i<2;i++) {
		CFRelease(keys[i]);
		CFRelease(nums[i]);
	}
	CFRelease(cs);
	CFRelease(cn);
	CFRelease(dict);
	CFRelease(services);
}


- (void)applicationSuspend:(GSEvent *)event {
	printf("Process Suspend\n");
	[self applicationWillTerminate];
	exit(0);
}


- (void)deviceOrientationChanged:(GSEvent *)event {
	UIHardwareOrientation	orientation	= [UIHardware deviceOrientation:YES];
	[_plasmaView setOrientationState:orientation];
	fflush(stdout);
}


- (void)acceleratedInX:(float)x Y:(float)y Z:(float)z {
	[_plasmaView modifyInertia:x y:y];
}
@end
