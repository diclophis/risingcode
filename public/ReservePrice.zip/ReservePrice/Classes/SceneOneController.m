//
//  SceneOneController.m
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SceneOneController.h"
#import <CoreGraphics/CoreGraphics.h>
#import <QuartzCore/QuartzCore.h>

@implementation SceneOneController


@synthesize myButton;
@synthesize myBackground;
@synthesize myBroken;
@synthesize myTimer;
@synthesize mySound;
@synthesize isFinished;
@synthesize almostFinished;


- (void)dealloc {
	[myButton release];
    [super dealloc];
}


-(id)init {
	if (self = [super init]) {
		timesTouched = 0;
		x = 0.0f;
		[self setView:[[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 480.0f)]];
		[[self view] setBackgroundColor:[UIColor blackColor]];
		[self setMyButton:[UIButton buttonWithType:UIButtonTypeCustom]];
		myBroken = [[UIImageView alloc] initWithFrame:CGRectOffset([[self view] frame], 23.0f, 8.0f)];
		[myBroken setImage:[UIImage imageNamed:@"Broken.png"]];
		
		myBackground = [[UIImageView alloc] initWithFrame:[[self view] frame]];
		[myBackground setImage:[UIImage imageNamed:@"Desktop.png"]];
		
		[myButton setAdjustsImageWhenHighlighted:NO];
		[myButton addTarget:self action:@selector(didTouchButton:) forControlEvents:UIControlEventTouchUpInside];
		[myButton setFrame:CGRectMake(162.0f, 121.0f, 72.0f, 72.0f)];
		[myButton setBackgroundColor:[UIColor clearColor]];
		[myButton setImage:[UIImage imageNamed:@"Icon.png"] forState:UIControlStateNormal];
		
		[[self view] addSubview:myBackground];
		[[self view] addSubview:myButton];
		
		mySound = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Glass" ofType:@"mp3"]] error:NULL];
		[mySound setDelegate:self];
		[mySound prepareToPlay];
		
	}
	return self;
}


-(IBAction)didTouchButton:(id)sender {
	timesTouched++;

	if (timesTouched >= 2) {
		[mySound stop];
		[mySound play];
		[[self view] addSubview:myBroken];
		[self performSelector:@selector(startSpin) withObject:self afterDelay:1.0f];
	}
	
	CABasicAnimation *fadeAnimation;
	
	fadeAnimation=[CABasicAnimation animationWithKeyPath:@"opacity"];
	fadeAnimation.duration=0.1f;
	fadeAnimation.repeatCount=0.0f;
	fadeAnimation.autoreverses=YES;
	fadeAnimation.fromValue=[NSNumber numberWithFloat:1.0f];
	fadeAnimation.toValue=[NSNumber numberWithFloat:0.5f];
	[[myButton layer] addAnimation:fadeAnimation forKey:@"animateOpacity"];
	
	
	CGRect frame = [myButton frame];
    int index;
	int numberOfShakes = 4;
	int vigourOfShake = 10.000f;

	CGMutablePathRef thePath = CGPathCreateMutable();
	CGPathMoveToPoint(thePath, NULL, CGRectGetMidX(frame), CGRectGetMidY(frame));
	
	for (index = 0; index < numberOfShakes; index++)
    {
        CGPathAddLineToPoint(thePath, NULL, CGRectGetMidX(frame) - vigourOfShake, CGRectGetMidY(frame));
        CGPathAddLineToPoint(thePath, NULL, CGRectGetMidX(frame) + vigourOfShake, CGRectGetMidY(frame));
    }
	
	// create an explicit keyframe animation that
	// animates the target layer's position property
	// and set the animation's path property
	CAKeyframeAnimation *theAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
	theAnimation.path=thePath;
	
	// create an animation group and add the keyframe animation
 
	CAAnimationGroup *theGroup = [CAAnimationGroup animation];
	theGroup.animations = [NSArray arrayWithObject:theAnimation];
	
	// set the timing function for the group and the animation duration
	theGroup.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	theGroup.duration = 0.25;
	// release the path
	//CFRelease(thePath);
	
	
	// adding the animation to the target layer causes it
	// to begin animating
	[[myButton layer] addAnimation:theGroup forKey:@"animatePosition"];

	

}

-(void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
	
}


-(void)startSpin {
	[self setAlmostFinished:YES];
	[self setMyTimer:[NSTimer scheduledTimerWithTimeInterval:1.0f / 30.0f target:self selector:@selector(tick:) userInfo:nil repeats:YES]];
}


-(void)tick:(NSTimer *)theTimer {
	
		
	//[[self view] setTransform:CGAffineTransformRotate([[self view] transform], tan(sin(x+=0.1f)))];
	//[[self view] setTransform:CGAffineTransformTranslate([[self view] transform], 0.0f, 20.0f * sin(x+=0.1f))];

	if ([[self view] frame].size.width < 40.0f) {
		[self setIsFinished:YES];
	} else {
		[[self view] setTransform:CGAffineTransformScale([[self view] transform], 0.95, 0.95)];
		[[self view] setTransform:CGAffineTransformRotate([[self view] transform], 0.25)];
	}
	 

	//reward.transform = CGAffineTransformScale(reward.transform, 0.95, 0.95);
	//reward.transform = CGAffineTransformRotate(reward.transform, 0.5f);
	//[reward setCenter:CGPointMake(round(reward.center.x + velocityScroll), reward.center.y + MAX_VELOCITY_Y)];
}




/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}




@end
