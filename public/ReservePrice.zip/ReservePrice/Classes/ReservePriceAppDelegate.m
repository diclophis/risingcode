//
//  ReservePriceAppDelegate.m
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//


#import "ReservePriceAppDelegate.h"
#import "SceneOneController.h"
#import "TPPlasmaView.h"
#import "SceneTwoController.h"
#import "StarsViewController.h"


@implementation ReservePriceAppDelegate


@synthesize window;
@synthesize mySceneOne;
@synthesize mySceneTwo;
@synthesize mySoundtrack;
@synthesize mySceneThree;


/*
 x = R cos(theta)
 y = R sin(theta)
 R = sqrt(x2 + y2)
 theta = atan2(y,x)
 */

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
	
	
	mySoundtrack = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Soundtrack" ofType:@"mp3"]] error:NULL];
	[mySoundtrack prepareToPlay];
	
	[window setBackgroundColor:[UIColor clearColor]];
	
	//TPPlasmaView *plasmaView = [[TPPlasmaView alloc] initWithFrame:[window frame]];
	//[window addSubview:plasmaView];
	//for (NSInteger i=0; i<3; i++) {
	//	[plasmaView createFragments:CGPointMake(100.0f, 100.0f + i)];
	//}
	
	mySceneOne = [[SceneOneController alloc] init];
	[mySceneOne addObserver:self forKeyPath:@"almostFinished" options:NSKeyValueObservingOptionNew context:NULL];
	[mySceneOne addObserver:self forKeyPath:@"isFinished" options:NSKeyValueObservingOptionNew context:NULL];
	[mySceneOne viewWillAppear:YES];
	[window addSubview:[mySceneOne view]];
	
	
	mySceneTwo = [[SceneTwoController alloc] init];
	mySceneThree = [[StarsViewController alloc] init];
	[mySceneThree addObserver:self forKeyPath:@"isFinished" options:NSKeyValueObservingOptionNew context:NULL];

	
    [window makeKeyAndVisible];
}


-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	if ([object isKindOfClass:[SceneOneController class]]) {
		if ([keyPath isEqualToString:@"almostFinished"]) {
			[mySoundtrack play];
			[mySceneOne removeObserver:self forKeyPath:@"almostFinished"];
		} else {
			[[mySceneOne view] removeFromSuperview];
			[mySceneOne removeObserver:self forKeyPath:@"isFinished"];
			[mySceneOne release];
			
			[mySceneThree viewWillAppear:YES];
			[window addSubview:[mySceneThree view]];

		}
	} else if ([object isKindOfClass:[StarsViewController class]]) {
		[UIView beginAnimations:@"wtf" context:NULL];
		[UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:window cache:NO];
		[UIView setAnimationDuration:1.5f];
		[mySceneThree removeObserver:self forKeyPath:@"isFinished"];
		[[mySceneThree view] removeFromSuperview];
		[mySceneThree release];
		[mySceneTwo viewWillAppear:YES];
		[window addSubview:[mySceneTwo view]];
		[UIView commitAnimations];

	}
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
