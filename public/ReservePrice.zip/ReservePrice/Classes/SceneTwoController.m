//
//  SceneTwoController.m
//  ReservePrice
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SceneTwoController.h"
#import "Letter.h"


@implementation SceneTwoController


@synthesize myTimer;
@synthesize myLetters;
@synthesize myBackground;


-(id)init {
	if (self = [super init]) {
		[self setView:[[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 480.0f)]];
		[[self view] setBackgroundColor:[UIColor clearColor]];
		
		
		myBackground = [[UIImageView alloc] initWithFrame:[[self view] frame]];
		[myBackground setImage:[UIImage imageNamed:@"Background2.png"]];
		
		[[self view] addSubview:myBackground];
		
		time = 0.0f;
		
		[self setMyLetters:[NSMutableArray arrayWithCapacity:0]];
		
		
		NSInteger i = 0;
		

		for (NSString *character in [@"o p e n g l  e a t  y o u r  h e a r t  o u t ,  s h o u t s :  r a v e n ,  v o l u n t e e r s ,  f e l l o w  h a c k e r s    k e e p  o n  t r u c k i n g  ! ! !  n a m a s t e" componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]) {
			Letter *a = [[Letter alloc] initWithCharacter:character];
			[a setCenter:CGPointMake((30.0f * i) + 320.0f, 100.0f)];
			[a setTextColor:[UIColor colorWithHue:(CGFloat)i/50.0f saturation:1.0f brightness:1.0f alpha:1.0f]];
			[myLetters addObject:a];
			[[self view] addSubview:a];
			
			i++;
		}
		
		

	}
	
	return self;
}


-(void)viewWillAppear:(BOOL)animated {
	[self setMyTimer:[NSTimer scheduledTimerWithTimeInterval:1.0f / 40.0f target:self selector:@selector(tick:) userInfo:nil repeats:YES]];
}


-(void)tick:(NSTimer *)theTimer {
	NSInteger index = 0;
	for (Letter *letter in myLetters) {
		CGFloat y = (30.0f * sin((2.0f * 3.1457f * 0.15f) * (time - (index * 0.5f))));
		[letter setCenter:CGPointMake(letter.center.x - 2.0f, 240.0f + y)];
		[letter setTransform:CGAffineTransformMakeRotation(-cos(time - (index * 0.5f)))];
		//[letter setTextColor:[UIColor colorWithHue:sin((2.0f * 3.1457f * 0.15f) * (time - (index * 0.5f))) saturation:1.0f brightness:1.0f alpha:1.0f]];


		index++;
	}
	
	CGAffineTransform rotate = CGAffineTransformMakeRotation(0.5f);
	CGAffineTransform skew = CGAffineTransformMakeScale(sin((2.0f * 3.1457f * 0.15f) * (time - (index * 0.5f))), 1.0f);
	[myBackground setTransform:CGAffineTransformConcat(rotate, skew)];


	time += 0.07f;
}		


/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
