//
//  StarsViewController.m
//  Demo
//
//  Created by Jon Bardin on 8/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "StarsViewController.h"
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>

@implementation StarsViewController

@synthesize isFinished;
@synthesize myTimer;

-(id)init
{
	if (self = [super initWithNibName:@"Stars" bundle:[NSBundle mainBundle]])
	{
		[self setStars:[NSMutableArray array]];
		loop = 0;
		angle = 0;
	}
	return self;
}
/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

@synthesize stars;

#define COUNT 50
#define PI 3.141592653589793238462643383279

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	CGRect rect = CGRectMake(160, 240, 5, 5);
	CGFloat totalPixels = 480 * 320;
	CGFloat segment = totalPixels / COUNT;
	CGFloat pi2 = 2 * PI;
	presin = malloc(COUNT * sizeof(CGFloat));
	precos = malloc(COUNT * sizeof(CGFloat));

	speeds = malloc(COUNT * sizeof(CGFloat));
	distances = malloc(COUNT * sizeof(int));
	for (int i = 0; i < COUNT; i++)
	{
		CGFloat radians = pi2 / (CGFloat)COUNT * (CGFloat)(i * 5 + random() % 5);
		presin[i] = sin(radians);
		precos[i] = cos(radians);
		speeds[i] = (CGFloat)(random() % 100)/50.0;
		distances[i] = random() % 100;
	}
	
	NSArray *frames = [NSArray arrayWithObjects:[UIImage imageNamed:@"Star1.png"], [UIImage imageNamed:@"Star2.png"], [UIImage imageNamed:@"Star3.png"], nil];
	
	for (int i = 0; i < COUNT; i++)
	{
		//UIView *img = [self createView];
		UIImageView *img = [[UIImageView alloc] init];
		
		[img setImage:[UIImage imageNamed:@"Star1.png"]];
		[img setAnimationImages:frames];
		[img setAnimationDuration:((random() % 3))];
		[img setAnimationRepeatCount:0];
		[stars addObject:img];
		
		/*
		float radians = 2 * PI;
		CATransform3D transform;
		transform = CATransform3DMakeRotation(radians, 0, 0, 1.0);
		
		// Create a basic animation to animate the layer's transform
		CABasicAnimation* animation;
		animation = [CABasicAnimation animationWithKeyPath:@"transform"];
		
		// Now assign the transform as the animation's value. While
		// animating, CABasicAnimation will vary the transform
		// attribute of its target, which for this transform will spin
		// the target like a wheel on its z-axis. 
		animation.toValue = [NSValue valueWithCATransform3D:transform];
		
		animation.duration = 0.1;  // two seconds
		animation.cumulative = YES;
		animation.repeatCount = 10000;
		[[img layer] addAnimation:animation forKey:@"rotation"];
		*/
		
		
		
		
		[[self view] addSubview:img];
		[img startAnimating];

		
	}
	[[self view] setBackgroundColor:[UIColor blackColor]];
	//[self next];
}


-(void)viewWillAppear:(BOOL)animated {
	//[self setMyTimer:[NSTimer scheduledTimerWithTimeInterval:1.0/30.0 target:self selector:@selector(next:) userInfo:nil repeats:YES]];
	[self performSelector:@selector(next:) withObject:nil afterDelay:1.0f/30.0f];
}




-(void)next:(NSTimer*)theTimer
{
	
//	[UIView beginAnimations:@"" context:nil];
		for (int i = 0; i < COUNT; i++)
		{
			UIImageView *star = [stars objectAtIndex:i];
			CGRect frame = [star frame];
			int distance = distances[i];
			CGFloat scale1 = distance * distance;
			CGFloat scale2 =  scale1 * distance;
//			frame.origin.x = [self circlePoCGFloatX:scale2 * speeds[i] / 60.0 andLoop:loop % 360 + i];
//			frame.origin.y = [self circlePoCGFloatY:scale2 * speeds[i] / 60.0 andLoop:i];
			frame.origin.x = [self circlePoCGFloatX:scale2 * speeds[i] / 60.0 andLoop:i];
			frame.origin.y = [self circlePoCGFloatY:scale2 * speeds[i] / 60.0 andLoop:i];
			distances[i]++;
			
			//if (!(random() % 10)) {
			//	[star startAnimating];
			//} else {
			//	[star stopAnimating];
			//}
			if (frame.origin.x > 320 || frame.origin.x < 0 || frame.origin.y > 480 || frame.origin.y < 0)
			{
				distances[i] = random() % 100;
				[star setFrame:frame];
				
	/*			[star removeFromSuperview];
				star = [self createView];
				[stars replaceObjectAtIndex:i withObject:star];
				[[self view] addSubview:star];
	 */
			}
			else
			{
			    frame.size.width = scale1 / 50.0;
			    frame.size.height = frame.size.width;
//				CGAffineTransform t = CGAffineTransformMakeRotation((distance/10) % 360);
//				[star setTransform:t];
			  [star setFrame:frame];
			}
			
		}
	BOOL black = loop % 200 > 99;
	int irgb = black ? loop % 100 : 100 - loop % 100;
	CGFloat frgb = ((CGFloat)irgb)/100;
//	[[self view] setBackgroundColor:[UIColor colorWithHue:frgb saturation:frgb brightness:frgb alpha:1]];
	//[[self view] setBackgroundColor:[UIColor colorWithRed:frgb green:frgb blue:frgb alpha:1]];
	loop++;
//	if ( loop % 8 == 0)
/*	{
		CGAffineTransform  xf = CGAffineTransformMakeRotation(((CGFloat)(loop % 360)) / 8 );
		[[self view] setTransform:xf];
	}
 */
//	[UIView commitAnimations];
	if (loop > 150) {
		//NSLog(@"wtf %@ %d", myTimer, [myTimer isValid]);
		//[myTimer setFireDate:[NSDate dateWithTimeIntervalSince1970:10000000000000]];
		//[myTimer invalidate];
		//[self setMyTimer:nil];
		[self setIsFinished:YES];
	} else {
		[self performSelector:@selector(next:) withObject:nil afterDelay:1.0f/30.0f];
	}
}

-(CGFloat)circlePoCGFloatX:(CGFloat)distance andRadians:(CGFloat) radians
{
	return 120.0f + round(distance * sin(radians));
}

-(CGFloat)circlePoCGFloatY:(CGFloat)distance andRadians:(CGFloat) radians
{
	return 240.0f + round(distance * cos(radians));
}

-(CGFloat)circlePoCGFloatX:(CGFloat)distance andLoop:(int) radians
{
	return 160.0f + round(distance * presin[radians]);
}

-(CGFloat)circlePoCGFloatY:(CGFloat)distance andLoop:(int) radians
{
	return 240.0f + round(distance * precos[radians]);
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToCGFloaterfaceOrientation:(UICGFloaterfaceOrientation)CGFloaterfaceOrientation {
    // Return YES for supported orientations
    return (CGFloaterfaceOrientation == UICGFloaterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}


@end
